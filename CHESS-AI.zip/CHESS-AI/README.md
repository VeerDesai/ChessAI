Basic Chess AI written in Python 3. Uses the Alpha-Beta algorithm to search for the best move.<br/>

How to Play:<br/>
    1.git clone https://github.com/Samarthhadimani/CHESS-AI.git<br/>
    2.cd CHESS-AI/src<br/>
    3.make    #Run the make file which installs all the requirements<br/>
    4.python3 main.py<br/>